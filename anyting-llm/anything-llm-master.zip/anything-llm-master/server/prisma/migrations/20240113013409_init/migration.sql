-- AlterTable
ALTER TABLE "workspaces" ADD COLUMN "chatModel" TEXT;
