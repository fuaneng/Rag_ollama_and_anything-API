-- AlterTable
ALTER TABLE "users" ADD COLUMN "pfpFilename" TEXT;
