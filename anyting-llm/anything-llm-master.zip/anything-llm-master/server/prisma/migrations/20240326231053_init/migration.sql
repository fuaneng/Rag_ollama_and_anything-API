-- AlterTable
ALTER TABLE "invites" ADD COLUMN "workspaceIds" TEXT;
